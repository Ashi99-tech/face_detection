import cv2
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from simple_facerec import SimpleFacerec
from PIL import Image, ImageTk

class FaceRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Recognition App")
        self.root.geometry("800x600")
        self.root.configure(bg="#90e0ef")

        # Start Button
        self.start_button = ttk.Button(self.root, text="Start Face Recognition", command=self.start_camera)
        self.start_button.pack(pady=20)

        # Frame for camera and output
        self.frame = tk.Frame(self.root, bg="#90e0ef", borderwidth=2, relief="groove")
        self.frame.pack(pady=20, padx=20, fill=tk.BOTH, expand=True)

        # Left Frame for Camera Output
        self.camera_frame = tk.Label(self.frame, bg="white")
        self.camera_frame.pack(side=tk.LEFT, padx=10)

        # Right Frame for Output Name
        self.name_label = tk.Label(self.frame, text="Name: ", bg="#90e0ef", font=("Helvetica", 16))
        self.name_label.pack(side=tk.RIGHT, padx=10)

        # Initialize face recognition
        self.sfr = SimpleFacerec()
        self.sfr.load_encoding_images("images/")

        self.cap = None
        self.running = False

    def start_camera(self):
        self.running = True
        self.start_button.config(state=tk.DISABLED)
        self.cap = cv2.VideoCapture(0)  # Open the camera

        if not self.cap.isOpened():
            messagebox.showerror("Camera Error", "Could not open camera.")
            self.running = False
            return

        threading.Thread(target=self.run_camera, daemon=True).start()

    def run_camera(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                messagebox.showerror("Camera Error", "Failed to read from camera.")
                break

            # Detect Faces
            face_locations, face_names = self.sfr.detect_known_faces(frame)
            name = "Unknown"  # Default name
            for face_loc, detected_name in zip(face_locations, face_names):
                y1, x2, y2, x1 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]
                name = detected_name  # Update name
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 200), 4)

            # Update the name label in the UI
            self.name_label.config(text=f"Name: {name}")

            # Resize the frame to fit the camera output area
            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(img)
            img = img.resize((500, 480), Image.ANTIALIAS)
            img_tk = ImageTk.PhotoImage(img)

            # Update the camera output frame
            self.camera_frame.img_tk = img_tk  # Keep a reference
            self.camera_frame.configure(image=img_tk)

        self.cap.release()

    def stop_camera(self):
        self.running = False
        self.start_button.config(state=tk.NORMAL)

    def quit_app(self):
        if self.running:
            self.stop_camera()
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    app = FaceRecognitionApp(root)
    root.protocol("WM_DELETE_WINDOW", app.quit_app)
    root.mainloop()
